/* MIT License
   Created by partheseas (Tyler Washburn)
   Copyright Tyler Washburn 2015
   partheseas.co Heroku App Delegate */

// Strict mode is the bomb guys. Really.
"use strict";

// Define all our variable up front because it's much prettier than having `var` eeeeeverywhere.
var http, fs, server;

// Import our Node modules
http = require( "http" )
fs = require( "fs" )

// Lets start up our server
server = http.createServer()
server.listen( process.env.PORT )

server.on( "request", function ( i, o ) {
	o.writeHead( 200, {
		Server: "Heroku Node/0.10 Weave -Something (pre-release) Teal/0.5"
	} )

	fs.readFile( "." + ( i.url === "/" ? "/index.html" : i.url ), function ( error, contents ) {
		o.write( contents || "404" )
		o.end()
	} )
} )