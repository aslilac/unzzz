window.addEventListener( "load", function () {
	document.getElementById( "header-foreground" ).style.opacity = 1;

	document.getElementById( "main-switch" ).addEventListener( "click", function ( event ) {
		if ( event.target.className !== "active" ) {
			[].forEach.call( document.querySelectorAll( "#main div" ), function ( element ) {
				element.className = ""
			} );

			[].forEach.call( document.querySelectorAll( "#main-switch li" ), function ( element ) {
				element.className = ""
			} );

			event.target.className = "active";
			document.getElementById( event.target.getAttribute( "data-section" ) ).className = "active"
		}
	} )
} )